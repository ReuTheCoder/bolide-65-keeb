%TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*%
%TF.CreationDate,2026-10-22T03:09:02-06:00*%
%TF.ProjectId,bolide-65-top_plate,626f6c69-6465-42d3-9635-2d746f705f70,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-10-22 03:09:02*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,6.500000*%
G04 APERTURE END LIST*
D10*
%TO.C,REF\u002A\u002A*%
X78800000Y-359400000D03*
%TD*%
%TO.C,REF\u002A\u002A*%
X392625000Y-359400000D03*
%TD*%
%TO.C,REF\u002A\u002A*%
X392625000Y-251575000D03*
%TD*%
%TO.C,REF\u002A\u002A*%
X78825000Y-251575000D03*
%TD*%
M02*
